#pragma once

#ifndef	__MemoryTrunk_H__
#define	__MemoryTrunk_H__



#include "IAllocator.h"


#include "./util/ObjectHandle.h"
#include "./globalDefine/Constant.h"
#include "./util/Log4cppWapper.h"
#include <boost/date_time/posix_time/posix_time.hpp>
//namespace Loki
//{

//struct CPPAllocator;
//struct CAllocator;
//struct VirtualMemoryAllocator;
//struct GlobalPolicy;
//class SingletonHolder;


//class IAllocator;

class	MemoryTrunk:
public	ObjectHandle<MemoryTrunk>
{
public:
      typedef ObjectHandle<MemoryTrunk> ThisBase;
      using ThisBase::m_ID;
      MemoryTrunk(IAllocator *Allocator,DWORD ChunkSize = 0,DWORD UseSize = 0,LPVOID lpvoid = NULL,DWORD RawChunkSize = 0,long ulHeritID = 0);
      virtual ~MemoryTrunk();
      MemoryTrunk(const MemoryTrunk &rhs);

      void Init(DWORD ChunkSize = 0,DWORD UseSize = 0,LPVOID lpvoid = NULL,DWORD RawChunkSize = 0,long ulHeritID = 0);

      MemoryTrunk CutMemory(DWORD ChunkSize,DWORD UseSize);

      bool    CheckStatus();
      void    Reset();
      bool    IsIntegrity() const;
      LPVOID  GetChunkTail() const;
      void    Deallocate();


      LPVOID  m_lpVoid;
      size_t  m_dwChunkSize;
      size_t  m_dwRawChunkSize;
      size_t  m_dwUseSize;
      size_t  m_dwGuardSize;
      long     m_RawChunkID;
      //DWORD   m_dwTimeCreateTime;
     // DWORD   m_dwThreadID;
      IAllocator *m_pAllocator;

	  boost::posix_time::ptime m_TimeCreateTime;



};

//}






#endif
