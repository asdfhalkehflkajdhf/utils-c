#ifndef  MEMORYPOOLBASE_H_
#define  MEMORYPOOLBASE_H_

#include "./globalDefine/GlobalDef.h"

class MemoryPoolBase
{
public:
	MemoryPoolBase()
	{};

	virtual ~MemoryPoolBase()
	{};

	virtual LPVOID Malloc(DWORD dwSize,DWORD dwGap_ = LOKI_DEFAULT_MEMORY_POOL_CHUNK_GAP_SIZE) = 0;
	
	virtual void Free(LPVOID lpVoid,DWORD UseSize = 0) = 0;
};

#endif
