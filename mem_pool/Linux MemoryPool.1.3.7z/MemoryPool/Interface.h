/*
 * Interface.h
 *
 *  Created on: 2009-7-14
 *      Author: yul
 */

#ifndef INTERFACE_H_
#define INTERFACE_H_



#ifdef __cplusplus
extern "C"
{
#endif

#include "./globalDefine/Constant.h"


#ifdef __cpluscplus
#define MEMORY_POOL_API extern
#else
#define MEMORY_POOL_API
#endif



MEMORY_POOL_API LPVOID Malloc(DWORD dwSize,DWORD dwGap_ = 4);
	
MEMORY_POOL_API void Free(LPVOID lpVoid,DWORD UseSize = 0);

#ifdef __cplusplus
}
#endif
#endif /* INTERFACE_H_ */
