/*
 * MemoryPoolAllocatori.cpp
 *
 *  Created on: 2009-7-14
 *      Author: yul
 */

#include "MemoryPoolAllocator.h"

/*template<typename MemoryPoolType>
typename MemoryPoolAllocator<MemoryPoolType>::TMemoryPool
    &MemoryPoolAllocator<MemoryPoolType>::memPool =
    SingletonHolder<MemoryPoolAllocator<MemoryPoolType>
                    ::TMemoryPool
                   >::GetInstance()GetMemoryPool;*/

template<typename MemoryPoolType>
void  *MemoryPoolAllocator<MemoryPoolType>::preallocate(size_t size)
{
/*  if(!GlobalPolicy<>::SingletonPolicy
      <typename MemoryPoolAllocator<typename MemoryPoolType>::TMemoryPool>::Destroyed()
     )
    {*/
    LPVOID  lpVoid = memPool.Malloc(size,0);
    //init(lpVoid,size);
    return lpVoid;
    /*}
   else
     return NULL;
*/
};

template<typename MemoryPoolType>
void *MemoryPoolAllocator<MemoryPoolType>::allocate(void *lpBase,size_t size)
{
      //assert(false);
   return lpBase;//memPool.Malloc(size);//new char[size];
      //return lpBase;
};

template<typename MemoryPoolType>
void MemoryPoolAllocator<MemoryPoolType>::deallocate(void *lpPtr,size_t size)
{
/* if(
  !GlobalPolicy<>::SingletonPolicy
                                                <
                                                        typename MemoryPoolAllocator<typename MemoryPoolType>::TMemoryPool
                                                >::Destroyed()
)*/
   memPool.Free(lpPtr);
};

template<typename MemoryPoolType>
void MemoryPoolAllocator<MemoryPoolType>::setguard(void *lpguard,size_t size)
{
   memset(lpguard,'\xff',size);
};

template<typename MemoryPoolType>
void MemoryPoolAllocator<MemoryPoolType>::init(void *lpvoid,size_t size)
{
   memset(lpvoid,0,size);
};

template<typename MemoryPoolType>
bool MemoryPoolAllocator<MemoryPoolType>::CheckStatus(void *lpVoid,size_t size)
{
    char *pchGuard = (char *)lpVoid;
    char Bound = '\xff';
    if (size && std::search_n(pchGuard,pchGuard+size,size,Bound) != pchGuard/*+dwGuardSize*/ )
    {
      //assert(false);
      return false;
    }
    else
      return true;
}
