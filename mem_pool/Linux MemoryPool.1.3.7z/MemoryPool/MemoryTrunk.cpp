#include "MemoryTrunk.h"
//#include <CAssert>

//namespace Loki
//{


	//template<int AllocateID>
MemoryTrunk::MemoryTrunk(IAllocator *pAllocator,
                                      DWORD ChunkSize /*= 0*/,
                                      DWORD UseSize /*= 0*/,
                                      LPVOID lpvoid /*= NULL*/,
                                      DWORD RawChunkSize /*= 0*/,
                                      long ulHeritID /*= 0*/)
: m_dwChunkSize(ChunkSize),
 m_dwRawChunkSize(RawChunkSize ? RawChunkSize : ChunkSize),
 m_dwUseSize(UseSize),
 m_dwGuardSize(ChunkSize-UseSize),
 m_lpVoid(lpvoid),
 m_TimeCreateTime((boost::posix_time::microsec_clock::local_time())),
 //m_dwThreadID(GetCurrentThreadId()),
 m_pAllocator(pAllocator),
 m_RawChunkID(m_ID)
 {
		//assert( ChunkSize >= UseSize && lpvoid );
		//assert(dwRawChunkSize>=dwChunkSize);

		if (ulHeritID)
		  m_RawChunkID = ulHeritID;
		//else
		//{
			//assert(false);
			//TRACE("New Trunk %d Trunk Size %d Used Size %d\n",ulID,ChunkSize,UseSize);
		//}

  Reset();
		//Allocator::init(lpVoid, dwUseSize);
		//Allocator::setguard(((char *)lpVoid) + dwUseSize, dwGuardSize);
  CheckStatus();

};

 MemoryTrunk::~MemoryTrunk()
 {
/*   
	 (*LogMessage)<< log4cpp::Priority::INFO
                                 <<__FUNCTION__<<" m_ID ="<<m_ID
                                 <<" m_RawChunkID ="<<m_RawChunkID
                                         <<" objectCounter ="<<getObjectCount()
                                 <<" m_dwChunkSize = "<<m_dwChunkSize;
*/


 }

	//template<int AllocateID>
MemoryTrunk::MemoryTrunk(const MemoryTrunk &rhs)
: m_TimeCreateTime(rhs.m_TimeCreateTime),//(boost::posix_time::microsec_clock::local_time())
//m_dwThreadID(GetCurrentThreadId())
m_lpVoid(rhs.m_lpVoid),
m_dwChunkSize( rhs.m_dwChunkSize),
m_dwRawChunkSize (rhs.m_dwRawChunkSize),
m_dwUseSize (rhs.m_dwUseSize),
m_dwGuardSize (rhs.m_dwGuardSize),
//dwTimeCreateTime = rhs.dwTimeCreateTime;
//dwTimeCreateTime = GetTickCount();
//ulID = rhs.ulID;
m_RawChunkID (rhs.m_RawChunkID),
m_pAllocator (rhs.m_pAllocator)
{
#if 0
  m_lpVoid = rhs.m_lpVoid;
  m_dwChunkSize = rhs.m_dwChunkSize;
  m_dwRawChunkSize = rhs.m_dwRawChunkSize;
  m_dwUseSize = rhs.m_dwUseSize;
  m_dwGuardSize = rhs.m_dwGuardSize;
  //dwTimeCreateTime = rhs.dwTimeCreateTime;
  //dwTimeCreateTime = GetTickCount();
  //ulID = rhs.ulID;
  m_RawChunkID = rhs.m_RawChunkID;
  m_pAllocator = rhs.m_pAllocator;
  //assert( dwChunkSize >= dwUseSize );
#endif
  //CheckStatus();
};

	//template<int AllocateID >
void	MemoryTrunk::Reset()
{
  /*AllocFactory::Instance(AllocateID)*/m_pAllocator->init(m_lpVoid,m_dwUseSize);
  /*AllocFactory::Instance(AllocateID)*/m_pAllocator->setguard(((char *)m_lpVoid) + m_dwUseSize, m_dwGuardSize);
};

	//template<int AllocateID >
void	MemoryTrunk::Init(DWORD ChunkSize /*= 0*/,
                                      DWORD UseSize /*= 0*/,
                                      LPVOID lpvoid /*= NULL*/,
                                      DWORD RawChunkSize /*= 0*/,
                                      long ulHeritID /*= 0*/
                                              )
{
  //assert( ChunkSize >= UseSize );
  m_dwChunkSize = ChunkSize;
  m_dwUseSize = UseSize;
  if (RawChunkSize)
          m_dwRawChunkSize = RawChunkSize;
  m_dwGuardSize = ChunkSize-UseSize;
  if (lpvoid)
          m_lpVoid = lpvoid;
  //dwTimeCreateTime = GetTickCount();
  if (ulHeritID)
    m_RawChunkID = ulHeritID;
  Reset();
  //Allocator::init(lpVoid,dwUseSize);
  //Allocator::setguard(((char *)lpVoid) + dwUseSize, dwGuardSize);
  CheckStatus();
};

MemoryTrunk
MemoryTrunk::CutMemory(DWORD ChunkSize,DWORD UseSize)
{
//assert( dwChunkSize >= dwUseSize );

//assert(dwUseSize >= UseSize);
  if (m_dwUseSize == UseSize)
  {
    //assert(ChunkSize == this->dwChunkSize);

    MemoryTrunk	allocateTrunk(m_pAllocator,ChunkSize,UseSize,m_lpVoid,m_dwRawChunkSize,m_RawChunkID);

    Init(m_dwChunkSize -ChunkSize,0,((char *)m_lpVoid)+ChunkSize);

    //assert( dwChunkSize >= dwUseSize );

    return allocateTrunk;
    //return MemoryTrunk(*this);

  }
  else
  {

    #if 1
      MemoryTrunk	allocateTrunk(m_pAllocator,ChunkSize,UseSize,m_lpVoid,m_dwRawChunkSize,m_RawChunkID);
    #else
      MemoryTrunk	allocateTrunk = *this;
      allocateTrunk.Init(ChunkSize,UseSize,m_lpVoid);
    #endif
    //Allocator::setguard(((char *)lpVoid) + dwUseSize, dwGuardSize);
    //Your Must Left a Revoke Memory Hole At the Cutted Memory Tail
    //�����ڴ�
    //allocateTrunk.dwChunkSize = ChunkSize;
    //allocateTrunk.lpVoid = freeTrunk.lpVoid;//pstrBuf +dwSize;

    //AllocateTable.insert(allocateTrunk);
    //
    if (m_dwUseSize >ChunkSize)
          Init(m_dwChunkSize -ChunkSize,m_dwUseSize - ChunkSize,((char *)m_lpVoid)+ChunkSize);
    else
          Init(m_dwChunkSize -ChunkSize,0,((char *)m_lpVoid)+ChunkSize);
    return allocateTrunk;
    //return MemoryTrunk(
    //	dwChunkSize -ChunkSize,
    //	dwUseSize - ChunkSize,
    //	((char *)lpVoid)+ChunkSize
    //	);

    #if 0
    m_dwChunkSize -= ChunkSize;
    m_dwUseSize	-= ChunkSize;
    m_dwGuardSize = dwChunkSize - m_dwUseSize;
    //assert(dwGuardSize = dwChunkSize)
    m_lpVoid = ((char *)m_lpVoid)+ChunkSize;
    //Allocator::setguard(((char *)lpVoid) + dwUseSize, dwGuardSize);
    return	allocateTrunk;
    #endif
}

};
	
bool MemoryTrunk::CheckStatus()
{
    char *pchGuard = (char *)m_lpVoid;
    pchGuard += m_dwUseSize;
    return m_pAllocator->CheckStatus(pchGuard,m_dwGuardSize);
#if 0
    char Bound = '\xff';
    if (std::search_n(pchGuard,pchGuard+dwGuardSize,dwGuardSize,Bound) != pchGuard/*+dwGuardSize*/ )
    {
            assert(false);
            return false;
    }
    else
            return true;

#endif
}

//template<int AllocateID >
bool MemoryTrunk::IsIntegrity() const
{
        return (m_dwChunkSize == m_dwRawChunkSize);
}

LPVOID	MemoryTrunk::GetChunkTail() const
{
        if(m_lpVoid)
        {
                return ((char *)m_lpVoid + m_dwChunkSize);
        }
        else
                return NULL;
}

void MemoryTrunk::Deallocate()
{
        if(m_pAllocator)
                m_pAllocator->deallocate(m_lpVoid,m_dwChunkSize);
}




//}


















