#pragma once
#ifndef	 MEMORYPOOL_H_
#define MEMORYPOOL_H_

#include "./globalDefine/GlobalDef.h"
#include "./globalDefine/Constant.h"
#include "./globalDefine/BoostConfigure.h"
#include "./globalDefine/globalAlgorithm.h"
#include <boost/threadpool.hpp>
#include <boost/multi_index_container.hpp>
#include "./util/ThreadPoolSingleton.h"

#include "IAllocator.h"
#include "MemoryPoolBase.h"
#include "MemoryTrunk.h"


//using namespace threadpool;
using namespace boost;
using namespace boost::multi_index;

class MemoryPool
:  public MemoryPoolBase
{
public:
        static const int MaxTrimSize = 10;

  	DWORD	m_dwChunkSize,m_dwIncrease,m_dwGap,m_dwExpiredSecond;
	IAllocator	*m_pAllocator;

	MemoryPool( IAllocator	*Allocator = &AllocFactory::Instance(LOKI_DEFAULT_SIMPLIFY_ALLOCATOR),
				DWORD dwChunkSize = LOKI_DEFAULT_CHUNK_SIZE/*ChunkSize*//*320*1024*/, 
				DWORD dwIncrease = LOKI_DEFAULT_MEMORY_POOL_INCREASE_SIZE/*Increase*//*64*1024*/,
				DWORD dwGap = LOKI_DEFAULT_MEMORY_POOL_CHUNK_GAP_SIZE/*Gap*/);
	
	virtual ~MemoryPool();
	
	virtual LPVOID Malloc(DWORD dwSize, DWORD dwGap_ = LOKI_DEFAULT_MEMORY_POOL_CHUNK_GAP_SIZE);
	
	virtual void Free(LPVOID lpVoid,DWORD UseSize = 0);
	
	size_t Trim(DWORD dwRequiredSize = 0xFFFFFFFF,DWORD nHit = 0xFFFFFFFF,DWORD nMaxCount = 0xFFFFFFFF);
	
	void GetParam(size_t &ChunkSize, size_t &Increase,size_t &Gap_);
	
	void SetParam(size_t ChunkSize_ = LOKI_DEFAULT_CHUNK_SIZE,size_t Increase_ = LOKI_DEFAULT_MEMORY_POOL_INCREASE_SIZE,size_t Gap_ = LOKI_DEFAULT_MEMORY_POOL_CHUNK_GAP_SIZE);
	
	void SetAllocatorPolicy(IAllocator	*Allocator);


	DWORD GetAllocMemSize();
	DWORD GetFreeMemSize();


	LPVOID HitTest(LPVOID lpVoid,bool bFree = true);


	/********************************************************************************************/
	/*					QueryMemoryStatus : Query Memory Status									*/
	/*					return Code  =  0 : In Free Memory Table								*/
	/*									1 : In Allocate Memory Table							*/
	/*								   -1 : Not In This Memory Pool								*/
	/********************************************************************************************/
	int	QueryMemoryStatus(LPVOID lpVoid,MemoryTrunk &memoryTrunk);



private:
	DWORD GetMemSize(bool bFree = true);
	template<DWORD Nth>	
	bool RunNtimes(typename boost::function0<void> func);
	void   InitOnce();
	bool MergeBack(LPVOID  lpVoid);
	bool MergeFront(LPVOID &lpVoid);
	bool FreeInner(LPVOID lpVoid/*,DWORD UseSize = 0*/);
	void FreeRun(DWORD dwTriger = 2);
	MemoryTrunk Preallocate(DWORD ChunkSize,DWORD UseSize = 0);
#if 0
	boost::recursive_mutex m_in_same_thread;
#endif
	std::set<LPVOID>		freeCache;
	//typedef typename boost::fast_pool_allocator<typename MemoryTrunk,AllocatorAdapter >	MemoryTable_Allocator;
        typedef boost::multi_index::multi_index_container
                        <

                        MemoryTrunk,
                        boost::multi_index::indexed_by
                        <
                        boost::multi_index::ordered_unique      /*0 idx*/
                        //boost::multi_index::hashed_unique             /*0 idx*/
                        <boost::multi_index::member<MemoryTrunk ,LPVOID,&MemoryTrunk::m_lpVoid> >,
                        boost::multi_index::ordered_non_unique  /*1 idx*/
                        <boost::multi_index::member<MemoryTrunk ,size_t,&MemoryTrunk::m_dwUseSize> >,
                        boost::multi_index::ordered_non_unique  /*2 idx*/
                        <boost::multi_index::member<MemoryTrunk ,size_t,&MemoryTrunk::m_dwChunkSize> >,
                        boost::multi_index::ordered_non_unique  /*3 idx*/
                        <boost::multi_index::member<MemoryTrunk,long,&MemoryTrunk::m_RawChunkID> >,
                        boost::multi_index::ordered_non_unique  /*4 idx*/
                        <boost::multi_index::member<MemoryTrunk ,size_t,&MemoryTrunk::m_dwUseSize> ,std::greater<DWORD> >,
                        boost::multi_index::ordered_non_unique  /*5 idx*/
                        <boost::multi_index::member<MemoryTrunk ,size_t,&MemoryTrunk::m_dwChunkSize>,std::greater<DWORD> >,
                        boost::multi_index::ordered_non_unique  /*6 idx*/
                        //<BOOST_MULTI_INDEX_CONST_MEM_FUN(MemoryTrunk,bool,IsIntegrity)>,
                        <boost::multi_index::const_mem_fun<MemoryTrunk,bool,&MemoryTrunk::IsIntegrity> >,
                        boost::multi_index::ordered_unique      /*7 idx*/
                        <boost::multi_index::const_mem_fun<MemoryTrunk,LPVOID,&MemoryTrunk::GetChunkTail> >,
                        //<BOOST_MULTI_INDEX_CONST_MEM_FUN(MemoryTrunk,LPVOID,GetChunkTail)>
                       // boost::multi_index::ordered_non_unique  /*8 idx*/
                       // <boost::multi_index::member<MemoryTrunk ,DWORD,&MemoryTrunk::m_dwThreadID> >,
                        boost::multi_index::hashed_unique               /*8 idx*/
                        <boost::multi_index::member<MemoryTrunk ,LPVOID,&MemoryTrunk::m_lpVoid> >,
                        boost::multi_index::hashed_unique               /*9 idx*/
                        <boost::multi_index::const_mem_fun<MemoryTrunk,LPVOID,&MemoryTrunk::GetChunkTail> >,


#if 1
                        boost::multi_index::ordered_non_unique  /*11 idx*/
                        <
                        boost::multi_index::composite_key
                        <
                        MemoryTrunk,
                        boost::multi_index::member<MemoryTrunk ,long,&MemoryTrunk::m_RawChunkID>,
                        boost::multi_index::member<MemoryTrunk ,size_t,&MemoryTrunk::m_dwRawChunkSize>,
                        boost::multi_index::member<MemoryTrunk ,size_t,&MemoryTrunk::m_dwChunkSize>
                        >,
#if 1
                        boost::multi_index::composite_key_compare
                        <
                        std::less<long>,
                        std::less<size_t>,
                        std::less<size_t>,
                        std::equal_to<bool>

                        >
#endif

                        >
#endif


                        >
#if 1
                        //,boost::fast_pool_allocator<typename MemoryTrunk,VirtualMemoryAllocator>
                        ,boost::fast_pool_allocator<MemoryTrunk>
#endif


                        > MemoryTable;


	//typedef typename MemoryTable::allocator_type MemoryTable_Allocator;

	MemoryTable	FreeTable,AllocateTable;

	boost::recursive_mutex m_Mutex;
public:
	size_t ClearExpire(DWORD &dwExpiredSec	);



};


#endif
