#pragma once

#ifndef	__AllocatorAdapter_H__
#define	__AllocatorAdapter_H__

#include <new>
#include <map>

//#ifndef	__Configure_H__
//#include "Configure.h"
//#endif


class AllocatorAdapter
{
public:
	AllocatorAdapter(void);
	virtual ~AllocatorAdapter(void);

		typedef std::size_t    size_type;
		typedef std::ptrdiff_t difference_type;
		
		typedef std::size_t    size_type;
		typedef std::ptrdiff_t difference_type;

		//static std::map<LPVOID,size_type>	MemCache;
		static  char * malloc(const size_t bytes);
		static void free(char * const block);

		typedef struct Chunk
		{
			LPVOID	lpVoid;
			DWORD	dwChunkSize;

			Chunk();

			Chunk(LPVOID lp,DWORD dwSize =0);

			Chunk(const Chunk &rhs);

			Chunk & operator = (const Chunk &rhs);

			operator LPVOID();
		}	Chunk;

		typedef std::map<LPVOID,typename Chunk >	TChunkCache;

		static TChunkCache	&ChunkCache;


};



#endif//__AllocatorAdapter_H__
