#pragma once

#ifndef GLOBALDEF_H_
#define GLOBALDEF_H_

#ifndef LOKI_DEFAULT_MUTEX
#define LOKI_DEFAULT_MUTEX ::Loki::Mutex
#endif

#ifndef LOKI_DEFAULT_THREAD_MODEL
#define LOKI_DEFAULT_THREAD_MODEL ObjectLevelLockable
#endif

#define PagesIncreament	4


#ifndef LOKI_DEFAULT_CHUNK_SIZE
#define LOKI_DEFAULT_CHUNK_SIZE	8*/*64**/1024
#endif

#ifndef LOKI_MAX_SMALL_OBJECT_SIZE
#define LOKI_MAX_SMALL_OBJECT_SIZE 256
#endif

#ifndef LOKI_DEFAULT_OBJECT_ALIGNMENT
#define LOKI_DEFAULT_OBJECT_ALIGNMENT 4
#endif
	
//#define LOKI_DEFAULT_MEMORY_POOL_CHUNK_SIZE	8*64*1024
#define LOKI_DEFAULT_MEMORY_POOL_INCREASE_SIZE	4*/*64**/1024
#define LOKI_DEFAULT_MEMORY_POOL_CHUNK_GAP_SIZE	4

#ifndef LOKI_DEFAULT_SIMPLIFY_ALLOCATOR
//#define LOKI_DEFAULT_SIMPLIFY_ALLOCATOR HeapAllocator
#define LOKI_DEFAULT_SIMPLIFY_ALLOCATOR TypeCAllocator/*TypeVirtualMemoryAllocator*/
//#define LOKI_DEFAULT_SIMPLIFY_ALLOCATOR ShareMemAllocator
#endif

#ifndef LOKI_THREAD_POOL_NUM
#define LOKI_THREAD_POOL_NUM 4
#endif

#ifndef LOKI_THREAD_POOL_TYPE
//#define LOKI_THREAD_POOL_TYPE lifo_pool
//#define LOKI_THREAD_POOL_TYPE fifo_pool
#define LOKI_THREAD_POOL_TYPE prio_pool

#endif
//}
#endif
