#pragma once

#ifndef	 BOOSTCONFIGURE_H_
#define	 BOOSTCONFIGURE_H_


//#if !defined(NDEBUG)
//#define BOOST_MULTI_INDEX_ENABLE_INVARIANT_CHECKING
//#define BOOST_MULTI_INDEX_ENABLE_SAFE_MODE
//#endif



#include <boost/config.hpp> /* keep it first to prevent nasty warns in MSVC */

////////Must Include At first
//#include <boost/archive/xml_oarchive.hpp>
//#include <boost/archive/xml_iarchive.hpp>
//
//#include <boost/archive/text_oarchive.hpp>
//#include <boost/archive/text_iarchive.hpp>
//#include <boost/serialization/base_object.hpp>
//////Data Struct//////////
//#include <boost/serialization/string.hpp>
//////Data Struct//////////
////////Must Include At first


//#include "pre_multi_index.hpp"
#include <boost/bind.hpp>
#include <boost/type_traits.hpp>

#include <boost/iterator.hpp>
#include <boost/iterator/indirect_iterator.hpp>
#include <boost/thread.hpp>
#include <boost/thread/condition.hpp>
//#include <boost/threadpool.hpp>
//#include <boost/random.hpp>

#include <boost/multi_index_container.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/mem_fun.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/multi_index/composite_key.hpp>
#include <boost/multi_index/sequenced_index.hpp>
#include <boost/multi_index/hashed_index.hpp>


#include <boost/pool/pool_alloc.hpp>
#include <boost/pool/object_pool.hpp>


//#include <boost/pool/pool_alloc.hpp>
//#include <boost/pool/object_pool.hpp>
//
//
//#include <boost/multi_index_container.hpp>
//#include <boost/multi_index/identity.hpp>
//#include <boost/multi_index/member.hpp>
//#include <boost/multi_index/mem_fun.hpp>
//#include <boost/multi_index/composite_key.hpp>
//#include <boost/multi_index/indexed_by.hpp>
//#include <boost/multi_index/ordered_index.hpp>
//#include <boost/multi_index/sequenced_index.hpp>
//#include <boost/multi_index/hashed_index.hpp>

#include <boost/thread/recursive_mutex.hpp>
#include <boost/smart_ptr.hpp>

#include <boost/smart_ptr.hpp>
#include <boost/tuple/tuple.hpp>
#include <boost/tuple/tuple_io.hpp>
#include <boost/tuple/tuple_comparison.hpp>


//#include <boost/mpl/deque.hpp>
//#include <boost/mpl/apply.hpp>
//#include <boost/mpl/lambda.hpp>
//#include <boost/mpl/unpack_args.hpp>
//#include <boost/mpl/placeholders.hpp>


//#include <boost/type_traits/remove_reference.hpp>

//#include <boost/detail/workaround.hpp>
//#if BOOST_WORKAROUND(BOOST_DINKUMWARE_STDLIB, == 1)
//#include <boost/archive/dinkumware.hpp>
//#endif



//#include <boost/preprocessor/stringize.hpp>

//#include <boost/serialization/serialization.hpp>

//#include <boost/serialization/nvp.hpp>
//#include <boost/serialization/access.hpp>
//#include <boost/serialization/utility.hpp>
//#include <boost/serialization/version.hpp>

//#include <boost/archive/text_oarchive.hpp>
//#include <boost/archive/text_iarchive.hpp>
//#include <boost/serialization/base_object.hpp>

//////Data Struct//////////
//#include <boost/serialization/string.hpp>
#if 0
#include <boost/serialization/list.hpp>
#include <boost/serialization/deque.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/serialization/map.hpp>
#include <boost/serialization/hash_map.hpp>
#endif
//////Data Struct//////////


//#include <boost/any.hpp>


using namespace boost;
//using boost::any_cast;

using namespace boost::multi_index;
//using namespace boost::serialization;
//using namespace threadpool;

//namespace mpl = boost::mpl;
//using namespace boost::mpl::placeholders;








#endif//__Boost_Configure_H__
