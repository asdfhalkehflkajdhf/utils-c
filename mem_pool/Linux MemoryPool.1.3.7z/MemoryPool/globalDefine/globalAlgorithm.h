/*
 * Globalalgorithm.h
 *
 *  Created on: 2009-7-13
 *      Author: yul
 */
#include <algorithm>

#ifndef GLOBALALGORITHM_H_
#define GLOBALALGORITHM_H_

template <typename StructType,typename MemType>
class InvadeTotal
{
public:
        typedef InvadeTotal thisType;

        InvadeTotal(MemType &Operand,	MemType StructType::*Mem)
                :Total(Operand),MemPtr(Mem)
        {}
        void	operator ()(const StructType &A) const
        {
                Total += A.*MemPtr;
                return ;//*this;
        }

        MemType &operator ()(MemType &Operand,const StructType &A) const
        {
                Operand += A.*MemPtr;
                return Operand;//*this;
        }



private:
        //�������ã������˿�������Ŀ���
        MemType &Total;
        MemType StructType::*MemPtr;
};

#endif
