/*
 * Constant.h
 *
 *  Created on: 2009-7-13
 *      Author: yul
 */

#ifndef CONSTANT_H_
#define CONSTANT_H_

typedef unsigned long DWORD;
typedef void * LPVOID;



#endif /* CONSTANT_H_ */
