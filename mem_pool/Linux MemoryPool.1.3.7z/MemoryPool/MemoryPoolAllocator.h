/*
 * MemoryPoolAllocatori.h
 *
 *  Created on: 2009-7-14
 *      Author: yul
 */

#ifndef MEMORYPOOLALLOCATOR_H_
#define MEMORYPOOLALLOCATOR_H_
#include "./globalDefine/GlobalDef.h"
#include "./globalDefine/Constant.h"
#include "./globalDefine/BoostConfigure.h"
#include "./globalDefine/globalAlgorithm.h"
#include <boost/threadpool.hpp>
#include <boost/multi_index_container.hpp>
#include "./util/ThreadPoolSingleton.h"
#include "./util/Log4cppWapper.h"
#include "IAllocator.h"
#include "MemoryPool.h"
#include "MemoryTrunk.h"

/*
struct  MemoryPoolWrap
{
        typedef
                //typename
                MemoryPool<

                                        //typename CPPAllocator,
                                        //typename CAllocator,
                                        //typename VirtualMemoryAllocator,
                                        //AllocatorID,

                                        //typename
                                        ThreadingModel
                                        //ClassLevelLockable,
                                        //ObjectLevelLockable,
                                        //SingleThreaded,


                                        //ChunkSize,Increase,Gap
                                >::thisType  TMemoryPool;

#if 0
        static typename TMemoryPool& GetMemoryPool(DWORD ChunkSize_ = ChunkSize,DWORD Increase_ = Increase,DWORD Gap_ = Gap);
#endif

};
*/




template<typename MemoryPoolType>
struct MemoryPoolAllocator
{
      static    void    *allocate(void *lpBase,size_t size);
      static    void    *preallocate(size_t size);
      static    void    deallocate(void *lpPtr,size_t size = 0);
      static    void    setguard(void *lpguard,size_t size);
      static    void    init(void *lpvoid,size_t size);
      static    bool    CheckStatus(void *lpvoid,size_t size);

      typedef    MemoryPoolType TMemoryPool;
private:
      static  MemoryPoolType &memPool;



};


#endif /* MEMORYPOOLALLOCATORI_H_ */
