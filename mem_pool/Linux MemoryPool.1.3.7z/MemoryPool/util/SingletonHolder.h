/*
 * SingletonHolder.h
 *
 *  Created on: 2009-7-13
 *      Author: yul
 */

#ifndef SINGLETONHOLDER_H_
#define SINGLETONHOLDER_H_


#include <boost/thread/recursive_mutex.hpp>
#include <boost/smart_ptr.hpp>
#include <string>
#include <stdlib.h>

using namespace std;



template <typename objectType>
class  SingletonHolder
{
  public:

	 ~SingletonHolder()
	  {

	  };

     static void FreeInstance()
      {
       spObject.reset();
      }

    static objectType& GetInstance()
    {
      //static ThreadPoolSingle lcw;
      //static bool bInited;
      if (!spObject.get())
       {
   		boost::recursive_mutex::scoped_lock lock(resourceMutex);
        if (!spObject.get())
          {

        	spObject = boost::shared_ptr<objectType>(new objectType());
        	atexit(FreeInstance);
          }
       }
      return *spObject;
    }
     private:
			SingletonHolder()
			{

			};

    	 static
    	 //SpObjectPoolType
    	 boost::shared_ptr<objectType>
    	 spObject;

    	 static boost::recursive_mutex resourceMutex;

  };

template <typename objectType>
boost::shared_ptr<objectType>
SingletonHolder<objectType>::spObject;

template <typename objectType>
boost::recursive_mutex
SingletonHolder<objectType>::resourceMutex;







#endif /* SINGLETONHOLDER_H_ */
