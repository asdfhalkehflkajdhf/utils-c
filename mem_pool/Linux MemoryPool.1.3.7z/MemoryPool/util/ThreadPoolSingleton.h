/*
 * ThreadPoolSingle.h
 *
 *  Created on: 2009-4-23
 *      Author: yul
 */

#ifndef THREADPOOLSINGLE_H_
#define THREADPOOLSINGLE_H_

#include <boost/thread/recursive_mutex.hpp>
#include <boost/smart_ptr.hpp>
#include <boost/threadpool.hpp>
#include <boost/bind.hpp>
#include <string>
#include "Log4cppWapper.h"

using namespace std;



template <typename threadpoolType = boost::threadpool::prio_pool,int ThreadPoolSize = 10>
class  ThreadPoolSingleton
{
  public:

	  typedef threadpoolType ThreadPoolType;
    static threadpoolType& GetInstance()
    {
      //static ThreadPoolSingle lcw;
      //static bool bInited;
      static int nTheadPoolSize = ThreadPoolSize;//spThreadPool->size();


      if (!spThreadPool.get())
       {
   		boost::recursive_mutex::scoped_lock lock(resourceMutex);
        if (!spThreadPool.get())
          {
        	spThreadPool = boost::shared_ptr<threadpoolType>(new threadpoolType());
        	spThreadPool->size_controller().resize(nTheadPoolSize);
           }
       }



     if( (spThreadPool->pending() +spThreadPool->active() )*9/10 > (nTheadPoolSize+2))
      {


    	  spThreadPool->size_controller().resize(
															  (spThreadPool->active()+spThreadPool->pending())
															  );
			(*LogMessage)<< log4cpp::Priority::INFO
			<<__FUNCTION__<<" ThreadPoolæ, ��ǰ��СΪ "<<nTheadPoolSize
			<<" �����ӵ� "<<spThreadPool->size();


      }
#if 0
     else if( (spThreadPool->pending() +spThreadPool->active())*4/5 > ThreadPoolSize
    		 &&  (spThreadPool->pending() +spThreadPool->active() )*4/5 < (nTheadPoolSize-1))
      {
   	  spThreadPool->size_controller().resize(
															  (spThreadPool->active()+spThreadPool->pending())*4/5
															  );
			(*LogMessage)<< log4cpp::Priority::INFO
			<<__FUNCTION__<<" ThreadPool��, ��ǰ��СΪ "<<nTheadPoolSize
			<<" �����ٵ� "<<spThreadPool->size();

      }
#endif
      nTheadPoolSize = spThreadPool->size();

      return *spThreadPool;
    }
     private:
	  //ThreadPoolSingle(){};
    /** Log4Cpp������� */
	  static boost::shared_ptr<threadpoolType> spThreadPool;
	  static boost::recursive_mutex resourceMutex;

	  //sd_log;
  };

template <typename threadpoolType,int ThreadPoolSize>
boost::shared_ptr<threadpoolType>
ThreadPoolSingleton<threadpoolType,ThreadPoolSize>::spThreadPool;

template <typename threadpoolType,int ThreadPoolSize>
boost::recursive_mutex
ThreadPoolSingleton<threadpoolType,ThreadPoolSize>::resourceMutex;



#endif /* THREADPOOLSINGLE_H_ */
