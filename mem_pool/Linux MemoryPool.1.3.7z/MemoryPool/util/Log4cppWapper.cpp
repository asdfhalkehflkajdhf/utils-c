/*
 * Log4cppWapper.cpp
 *
 *  Created on: 2009-5-27
 *      Author: root
 */

#include "Log4cppWapper.h"


     log4cpp::Category* Log4CppWapper::sd_log = NULL;
  	  boost::recursive_mutex Log4CppWapper::resourceMutex;



Log4CppWapper::Log4CppWapper()
{

}


Log4CppWapper::~Log4CppWapper()
{

}

log4cpp::Category* Log4CppWapper::GetInstance()
{
  if (!sd_log)
  {
 		boost::recursive_mutex::scoped_lock(resourceMutex);
	   if (!sd_log)
        {
	    InitInstance();
        }
  }
  return sd_log;
}

void Log4CppWapper::InitInstance()
{
	log4cpp::PropertyConfigurator::configure("log4cpp.properties");
	sd_log = &log4cpp::Category::getInstance(string("MemoryPool"));
};



