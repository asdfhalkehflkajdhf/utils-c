/*
 * ObjectCounter.h
 *
 *  Created on: 2009-3-31
 *      Author: root
 */

#ifndef OBJECTHANDLE_H_
#define OBJECTHANDLE_H_

//#include <Ice/Ice.h>
//#include <IceUtil/IceUtil.h>

//#include "../../interface/common.h"
#include <boost/detail/atomic_count.hpp>
#include <boost/thread/recursive_mutex.hpp>
#include <boost/pool/pool_alloc.hpp>
#include <boost/thread/shared_mutex.hpp>
#include <map>
//#include <boost/smart_ptr.hpp>
//#include <boost/enable_shared_from_this.hpp>
using namespace std;

template<typename derived>
class ObjectHandle //: public boost::enable_shared_from_this<derived>
{
public:
	static boost::detail::atomic_count objCounter,objSequence;
	static map<long,void *,std::less<long>,boost::pool_allocator<std::pair<long,void *> > > resourcePool;
	//static map<void *,long,std::less<void *>,boost::pool_allocator<std::pair<void *,long> > > resourceIDPool;
	//static boost::shared_ptr<boost::recursive_mutex> resourceMutex;
	static boost::shared_ptr<boost::shared_mutex> resourceMutex;

	long m_ID;
	ObjectHandle();
	virtual ~ObjectHandle();
	static long getObjectCount();
	static derived *getObject(long ID);
	static long getMaxObjectID();
	static long getMinObjectID();

	long getObjectID();

	operator long();

	static void close(long handle);
	static void closeAll();
};

template<typename derived>
boost::detail::atomic_count ObjectHandle<derived>::objCounter(0);

template<typename derived>
boost::detail::atomic_count ObjectHandle<derived>::objSequence(0);

template<typename derived>
map<long,void *,std::less<long>,boost::pool_allocator<std::pair<long,void *> > > ObjectHandle<derived>::resourcePool;


//template<typename derived>
//map<void *,long,std::less<void *>,boost::pool_allocator<std::pair<void *,long> > > ObjectHandle<derived>::resourceIDPool;


template<typename derived>
boost::shared_ptr<boost::shared_mutex> ObjectHandle<derived>::resourceMutex(new boost::shared_mutex());


template<typename derived>
ObjectHandle<derived>::ObjectHandle()
{
	++objCounter;
	boost::unique_lock<boost::shared_mutex> lock(*resourceMutex);
	++objSequence;
	m_ID = objSequence;
	resourcePool[m_ID] = static_cast<void *>(static_cast<derived *>(this));


}

template<typename derived>
ObjectHandle<derived>::~ObjectHandle()
{
	boost::unique_lock<boost::shared_mutex> lock(*resourceMutex);

	if(resourcePool.count(m_ID))
	{
		--objCounter;
		resourcePool.erase(m_ID);
	}
}

template<typename derived>
ObjectHandle<derived>::operator long()
{
	return m_ID;
}

template<typename derived>
long ObjectHandle<derived>::getObjectCount()
{
	return objCounter;

}

template<typename derived>
long ObjectHandle<derived>::getObjectID()
{
	return m_ID;

}





template<typename derived>
derived *ObjectHandle<derived>::getObject(long ID)	//IceUtil::RWRecMutex RLock(*resourceMutex);

{

	boost::shared_lock<boost::shared_mutex> lock(*resourceMutex);

	if(resourcePool.count(ID))
		return static_cast<derived *>(resourcePool[ID]);
	else
		return NULL;

}
template<typename derived>
long ObjectHandle<derived>::getMaxObjectID()
{
	boost::shared_lock<boost::shared_mutex> lock(*resourceMutex);
	if(resourcePool.size()>0)
	{
	typename map<
					long,void *,std::less<long>,
					boost::pool_allocator<std::pair<long,void *>//,
												//user_allocator_for_memorypool
												>
					>::reverse_iterator it = resourcePool.rbegin();
	return it->first;
	}
	else
		return -1;

}


template<typename derived>
long ObjectHandle<derived>::getMinObjectID()
{
	boost::shared_lock<boost::shared_mutex> lock(*resourceMutex);
	if(resourcePool.size()>0)
	{
	typename map<
					long,void *,std::less<long>,
					boost::pool_allocator<std::pair<long,void *>//,
												//user_allocator_for_memorypool
												>
					>::iterator it = resourcePool.begin();
	return it->first;
	}
	else
		return -1;
}



template<typename derived>
void ObjectHandle<derived>::close(long handle)
{
	delete static_cast<derived *>(resourcePool[handle]);

}

template<typename derived>
void ObjectHandle<derived>::closeAll()
{
	for ( typename map<long,void *,std::less<long>,boost::pool_allocator<std::pair<long,void *> > >::iterator it = resourcePool.begin();
			it != resourcePool.end(); it = resourcePool.begin())
	{
		delete static_cast<derived *>(it->second);
	}

}


#endif /* OBJECTHANDLE_H_ */
