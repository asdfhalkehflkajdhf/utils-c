/*
 * Log4cppWapper.h
 *
 *  Created on: 2009-4-3
 *      Author: yul
 */

#ifndef LOG4CPPWAPPER_H_
#define LOG4CPPWAPPER_H_

#include <log4cpp/Category.hh>
#include <log4cpp/FileAppender.hh>
#include <log4cpp/BasicLayout.hh>
#include <log4cpp/CategoryStream.hh>
#include <log4cpp/PropertyConfigurator.hh>
#include <string>
#include <boost/thread/recursive_mutex.hpp>
#include <boost/smart_ptr.hpp>

using namespace std;


#define LogMessage (Log4CppWapper::GetInstance())



class  Log4CppWapper
{
  public:
     /** ȡ��Log4CppWapper�ĵ���ʵ�� */
    static log4cpp::Category* GetInstance();
     /** ��ʼ������ʵ�� */
    static void InitInstance();
    ~Log4CppWapper();
  private:
    Log4CppWapper();
    /** Log4Cpp������� */
    static log4cpp::Category* sd_log;
  	 static boost::recursive_mutex resourceMutex;

  };


#endif /* LOG4CPPWAPPER_H_ */
