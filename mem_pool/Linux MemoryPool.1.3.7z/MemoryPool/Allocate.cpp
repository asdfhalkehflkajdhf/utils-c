
#include "Allocate.h"
#include "./util/SingletonHolder.h"

#if 0
#include "TypeManip.h"
#include "TypeTraits.h"
#include "Typelist.h"
#include "ValueList.h"
#include "NullType.h"
#include "EmptyType.h"
#include "HierarchyGenerators.h"
#include "Visitor.h"

#ifndef __GlobalDef_H___
#include "GlobalDef.h"
#endif


#ifndef __GlobalType_H___
#include "GlobalType.h"
#endif


#ifndef THREADS_H_
#include "Threads.h"
#endif


#ifndef	__GlobalPolicy_H__
#include "GlobalPolicy.h"
#endif



#ifndef SINGLETON_INC_
#include "Singleton.h"
#endif

#endif

#ifndef	__ALLOCATE_CPP__
#define	__ALLOCATE_CPP__
//namespace Loki
//{


unsigned int GetLongevity(IAllocator *)
{
	return 6;
}


IAllocator &AllocFactory::Instance(int typeID)
{
	switch(typeID)
	{
	case TypeCPPAllocator:
		return SingletonHolder<CPPAllocator
                                        //typename CreateUsingNew,
                                        //typename SingletonWithLongevity
                                        >::GetInstance();

	case TypeCAllocator:
		return SingletonHolder<
                              CAllocator
                              //typename CreateUsingNew,
                              //typename SingletonWithLongevity
                              >::GetInstance();


	}

}





	void	*CPPAllocator::preallocate(size_t size)
	{
		LPVOID	lpVoid = new char[size];
		init(lpVoid,size);
		return lpVoid;
	};
	void	*CPPAllocator::allocate(void *lpBase,size_t size)
	{
		//assert(false);
		return new char[size];
		//return lpBase;
	};

	void	CPPAllocator::deallocate(void *lpPtr,size_t size)
	{
		delete []lpPtr;
	};

	void	CPPAllocator::setguard(void *lpguard,size_t size)
	{
		memset(lpguard,'\xff',size);
	};

	void	CPPAllocator::init(void *lpvoid,size_t size)
	{
		memset(lpvoid,0,size);
	};

	bool	CPPAllocator::CheckStatus(void *lpVoid,size_t size)
	{
		char *pchGuard = (char *)lpVoid;
		char Bound = '\xff';
		if (size && std::search_n(pchGuard,pchGuard+size,size,Bound) != pchGuard/*+dwGuardSize*/ )
		{
			//assert(false);
			return false;
		}
		else
			return true;
	}


	//std::map<LPVOID,CPPAllocator::size_type>	CPPAllocator::MemCache;

	char * CPPAllocator::malloc(const size_t bytes)
	{
		LPVOID	lpVoid	=	preallocate(bytes);
		init(lpVoid,bytes);
		MemCache[lpVoid] = bytes;
		return	(char *)lpVoid;

	};
	void CPPAllocator::free(char * const block)
	{

		//assert(MemCache.count(block));
		deallocate(block,MemCache[block]);
		MemCache.erase(block);

	};






//Plain C Allocator
	void	*CAllocator::preallocate(size_t size)
	{
		LPVOID	lpVoid = std::malloc(size);
		init(lpVoid,size);
		return lpVoid;
	};
	void	*CAllocator::allocate(void *lpBase,size_t size)
	{
		//assert(false);
		return std::malloc(size);
		//return lpBase;
	};

	void	CAllocator::deallocate(void *lpPtr,size_t size)
	{
		std::free(lpPtr);

	};

	void	CAllocator::setguard(void *lpguard,size_t size)
	{
		memset(lpguard,'\xff',size);
	};

	void	CAllocator::init(void *lpvoid,size_t size)
	{
		memset(lpvoid,0,size);
	};

	bool CAllocator::CheckStatus(void *lpVoid,size_t size)
	{
		char *pchGuard = (char *)lpVoid;
		char Bound = '\xff';
		if (size && std::search_n(pchGuard,pchGuard+size,size,Bound) != pchGuard/*+dwGuardSize*/ )
		{
			//assert(false);
			return false;
		}
		else
			return true;
	}


	//std::map<LPVOID,CAllocator::size_type>	CAllocator::MemCache;

	char * CAllocator::malloc(const size_t bytes)
	{
		LPVOID	lpVoid	=	preallocate(bytes);
		init(lpVoid,bytes);
		MemCache[lpVoid] = bytes;
		return	(char *)lpVoid;

	};
	void CAllocator::free(char * const block)
	{

		//assert(MemCache.count(block));
		deallocate(block,MemCache[block]);
		MemCache.erase(block);

	};










//}//namespace Loki;

















#endif//__ALLOCATE_CPP__
