/*
 * MemoryPool.cpp
 *
 *  Created on: 2009-7-14
 *      Author: yul
 */

#include "MemoryPool.h"
#include <numeric>

MemoryPool::MemoryPool(IAllocator *Allocator,
                        DWORD dwChunkSize_,
                        DWORD dwIncrease_ ,
                        DWORD dwGap_
) : m_dwChunkSize(dwChunkSize_),
m_dwIncrease(dwIncrease_),
m_dwExpiredSecond(120),
m_pAllocator(Allocator)
//,ThreadPool(GetThreadPool< typename shared_ptr<LOKI_THREAD_POOL_TYPE> >())
{
  //GetThreadPool< typename smart_pool<LOKI_THREAD_POOL_TYPE> >()
  //ThreadPool->size_controller().resize(LOKI_THREAD_POOL_NUM);
  //TRACE("%s\n",typeid(ThreadModel).name());
    m_dwGap = 1;
    while((dwGap_>>=1))
    {
            m_dwGap <<= 1;
    }
#if 0
                //Not Lazy first Preallocate
                MemoryTrunk     memoryTrunk = Preallocate(dwChunkSize);
                assert(memoryTrunk.lpVoid);
                FreeTable.insert(memoryTrunk);
#endif
}

void MemoryPool::SetAllocatorPolicy(IAllocator  *Allocator)
{
    boost::recursive_mutex::scoped_lock lock(m_Mutex);
  //Lock Lock (this);
    m_pAllocator = Allocator;
}

MemoryPool::~MemoryPool()
{
  //ThreadPool->empty();

  //ClearThreadPool< typename smart_pool<LOKI_THREAD_POOL_TYPE> >();
{

  boost::recursive_mutex::scoped_lock lock(m_Mutex);
    //Lock Lock (this);

  //  cout<< __FUNCTION__<<"Total Memory:"<< (GetFreeMemSize()>>10)<<"Allocate Memory:"<<(GetAllocMemSize()>>10)<<endl;
    MemoryTable::nth_index<0>::type &idx=get<0>(AllocateTable);
    for( nth_index_iterator<MemoryTable,0>::type it = idx.begin();it!= idx.end();it++ /*it = idx.begin()*/)
    {
          //MemoryTrunk   memoryTrunk;
      MemoryTrunk memoryTrunk = *it;
    #if 0
              Free(memoryTrunk.lpVoid);
    #else
      FreeTable.insert(memoryTrunk);
    #endif
    }
    AllocateTable.clear();
    {
      //�ϲ������ڴ��
      //Stop to Schedule FreeRun
      freeCache.clear();
      //Stop to Schedule ClearExpire
      m_dwExpiredSecond = 0;

      (*LogMessage)<< log4cpp::Priority::INFO
                   <<__FUNCTION__<<"Before Trim";

      size_t size = Trim();
      if ( size )
        {
                //nth_index<MemoryTable,3>::type &idxFree3=get<3>(FreeTable);

                //std::copy ( idxFree3.begin(), idxFree3.end() ,
                //      std::ostream_iterator<long *> ( std::cout, " ") );
        //cout<< __FUNCTION__<<"Trim "<<size<<"Total "<<FreeTable.size()<<" Chunk"<<"Total Memory:"<< (GetFreeMemSize()>>10)<<"Allocate Memory:"<<(GetAllocMemSize()>>10)<<endl;
   //     (*LogMessage)<< log4cpp::Priority::INFO<<__FUNCTION__<<"Trim "<<size<<"Total "<<FreeTable.size()<<" Chunk"<<"Total Memory:"<< (GetFreeMemSize()>>10)<<"Allocate Memory:"<<(GetAllocMemSize()>>10);
        }

      (*LogMessage)<< log4cpp::Priority::INFO
                   <<__FUNCTION__<<"After Trim";



    }
}
    //if(!GlobalPolicy<>::SingletonPolicy<typename smart_pool<lifo_pool> >::BeDestroyed())
    //      ThreadPool->join(GetTimeStamp(5));

    {
      boost::recursive_mutex::scoped_lock lock(m_Mutex);
           //Lock Lock (this);
            //����ͷ��ڴ��
            //TRACE("End\n");
      nth_index<MemoryTable,0>::type &idxFree=get<0>(FreeTable);
      for( nth_index_iterator<MemoryTable,0>::type it = idxFree.begin();it!= idxFree.end();it++ /*= idxFree.begin()*/)
        {
           MemoryTrunk  memoryTrunk = *it;
          // (*LogMessage)<< log4cpp::Priority::INFO<<__FUNCTION__<<" Deallocate Trunk "<<memoryTrunk.m_RawChunkID;

           // cout<<"Deallocate Trunk"<<memoryTrunk.ulID<<endl;

               /* TRACE("Deallocate Trunk [%d] 0x%lx size %d K Raw Chunk Size %d K\n",
                                                        memoryTrunk.ulID,
                                                        memoryTrunk.m_lpVoid,
                                                        memoryTrunk.m_dwChunkSize>>10,
                                                        memoryTrunk.m_dwRawChunkSize>>10
                         );*/

                //AllocFactory::Instance(AllocatorID).
                //memoryTrunk.m_pAllocator->deallocate(memoryTrunk.lpVoid,memoryTrunk.dwChunkSize);
                memoryTrunk.Deallocate();
        }

            FreeTable.clear();
//MemoryTable_Allocator.ChunkCache.clear();
            //MemoryTable_Allocator.get_allocator().purge_memory();

            //MemoryTable_Allocator::purge_memory();
            //boost::pool<Allocator>::purge_memory();

            //ThreadPool->empty();
            ThreadPoolSingleton<>::GetInstance().size_controller().resize(0);
            ThreadPoolSingleton<>::GetInstance().clear();

    }

    //ThreadPool->empty();
}


LPVOID MemoryPool::Malloc(DWORD dwUseSize,DWORD dwGap_ )
{

//Profile(PerformanceTest);



        if (dwUseSize==0)
                return NULL;



/*        DWORD dwThread  = GetCurrentThreadId();


        if ( IsThreadReEnter(dwThread) && !ThreadIDCache.count(dwThread))
        {
                HANDLE hThread = OpenThread(THREAD_TERMINATE |THREAD_QUERY_INFORMATION,TRUE ,dwThread);

                if (hThread )
                {
                        //if (!AcquireThreadHandleSet.count(hThread))
                        Lock Lock (this);
                        AcquireThreadHandleSet.insert(hThread);
                        ThreadIDCache[dwThread] = hThread;
                }
        }
 */

        boost::recursive_mutex::scoped_lock lock(m_Mutex);
        //Lock Lock (this);
        //Lazy first Preallocate
        static  bool bInitOnce = false;
        //boost::function<void (typename thisType)> func = InitOnce;
        if(!bInitOnce)
                bInitOnce = (bInitOnce ? bInitOnce:RunNtimes<1>(boost::bind(&MemoryPool::InitOnce,this)));
        DWORD   dwChunkSize;
        if (dwGap_ && dwGap_ != m_dwGap)
        {
             DWORD   dwResult = 1;
             while((dwGap_>>=1))
                {
                        dwResult <<= 1;
                }
                dwGap_ = dwResult;
        }

        if(!dwGap_)
                dwChunkSize  = dwUseSize;
        else
                dwChunkSize  = (( dwUseSize + dwGap_ )/ dwGap_)* dwGap_;

        DWORD   dwGuardSize = dwChunkSize - dwUseSize;


        nth_index<MemoryTable,1>::type &idx=get<1>(FreeTable);
        nth_index_iterator<MemoryTable,1>::type it = idx.lower_bound(dwUseSize);

        nth_index<MemoryTable,2>::type &idx2=get<2>(FreeTable);
        nth_index_iterator<MemoryTable,2>::type it2;

        //ASSERT(it->dwSize >= dwSize);
        do
        {
                it2 = idx2.lower_bound(dwChunkSize);

                if ( it != idx.end() && it->m_dwChunkSize >= dwChunkSize  )
                {//Find Invoke Free Reusable Memory
                        //MemoryTrunk   allocateTrunk , freeTrunk;
                //  (*LogMessage)<< log4cpp::Priority::INFO
                 //              <<__FUNCTION__<<" find free chunk  "<<"dwChunkSize = "<<dwChunkSize;
                        MemoryTrunk freeTrunk = *it;
                        idx.erase(it);
                        //Not Need To Merge
                        freeCache.erase(freeTrunk.m_lpVoid);

                        assert(freeTrunk.m_dwUseSize >= dwUseSize && freeTrunk.m_dwChunkSize >= dwChunkSize);

                        if (//dwChunkSize == freeTrunk.dwChunkSize
                                /*&&*/ freeTrunk.m_dwUseSize == dwUseSize)
                              {
                                assert(freeTrunk.m_dwChunkSize >= dwChunkSize );


                                if (freeTrunk.m_dwChunkSize == dwChunkSize)
                                {//accuracy Match Memory Block
                                        MemoryTrunk allocateTrunk = freeTrunk;/*(
                                                                                                freeTrunk.dwChunkSize,
                                                                                                freeTrunk.dwUseSize,
                                                                                                freeTrunk.lpVoid
                                                                                        );*/
                                        allocateTrunk.Init(freeTrunk.m_dwChunkSize,dwUseSize);
                                        AllocateTable.insert(allocateTrunk);
                                        return allocateTrunk.m_lpVoid;
                                }
                          else if(freeTrunk.m_dwChunkSize > dwChunkSize)
                                {
                                        MemoryTrunk allocateTrunk = freeTrunk.CutMemory(dwChunkSize,dwUseSize);
                                        AllocateTable.insert(allocateTrunk);

                                        if (freeTrunk.m_dwChunkSize != 0)
                                                FreeTable.insert(freeTrunk);
                                        return  allocateTrunk.m_lpVoid;

                                }
                        }
                   else //if (freeTrunk.dwUseSize >= dwUseSize)
                        {
                                assert(freeTrunk.m_dwUseSize > dwUseSize && freeTrunk.m_dwChunkSize >= dwChunkSize);

                                MemoryTrunk allocateTrunk = freeTrunk.CutMemory(dwChunkSize,dwUseSize);
                                AllocateTable.insert(allocateTrunk);

                                if (freeTrunk.m_dwChunkSize != 0)
                                        FreeTable.insert(freeTrunk);
                                return  allocateTrunk.m_lpVoid;
                        }

                    }
                else if (it2 != idx2.end())
                {//Now Find Unused Revoke Memory
                        MemoryTrunk freeTrunk = *it2;
                       // (*LogMessage)<< log4cpp::Priority::INFO
                        //                            <<__FUNCTION__<<" Now Find Unused Revoke Memory  "
                        //                            <<" dwChunkSize = "<<freeTrunk.m_dwChunkSize ;

                        idx2.erase(it2);
                        //Not Need To Merge
                        freeCache.erase(freeTrunk.m_lpVoid);

                        assert(freeTrunk.m_dwChunkSize >= dwChunkSize );

                        freeTrunk.Init(freeTrunk.m_dwChunkSize,dwUseSize);

                   if(freeTrunk.m_dwChunkSize > dwChunkSize)
                        {
                                MemoryTrunk allocateTrunk = freeTrunk.CutMemory(dwChunkSize,dwUseSize);
                                AllocateTable.insert(allocateTrunk);
                                if (freeTrunk.m_dwChunkSize != 0)
                                        FreeTable.insert(freeTrunk);
                                return  allocateTrunk.m_lpVoid;
                        }
                   else if (freeTrunk.m_dwChunkSize == dwChunkSize)
                   {//accuracy Match Memory Block
                                MemoryTrunk allocateTrunk = freeTrunk;
                                allocateTrunk.Init(freeTrunk.m_dwChunkSize,dwUseSize);
                                AllocateTable.insert(allocateTrunk);
                                return allocateTrunk.m_lpVoid;
                        }
                }
                else
                {
                 // (*LogMessage)<< log4cpp::Priority::INFO
                  //              <<__FUNCTION__<<" Now trim Memory  ";
                               //   <<" dwChunkSize = "<<freeTrunk.m_dwChunkSize ;



                        size_t size = Trim(     dwChunkSize,(DWORD) MaxTrimSize
                                                              //  (DWORD)AcquireThreadHandleSet.size()*2
                                                                //,(DWORD)AcquireThreadHandleSet.size()*6
                                                                );
                        if (size == MaxTrimSize)
                            //AcquireThreadHandleSet.size()*2)//���������ڴ��
                        {
                                //ThreadPool->schedule(boost::bind(ClearExpire,this,dwExpiredSecond));
                                //TRACE("Trim %d Trunk Free Memory %u K Allocate Memory %u K\n",
                                   //      size,GetFreeMemSize()>>10,GetAllocMemSize()>>10 );
                                //(*LogMessage)<< log4cpp::Priority::INFO
                                  //                               <<__FUNCTION__<<" Trim "<<size
                                   //                              <<"k  Trunk Free Memory "<<(GetFreeMemSize()>>10)
                                    //                             <<"k  Allocate Memory"<<(GetAllocMemSize()>>10)<<"k";


                        }
#if 0
                        if (size &&((it = idx.lower_bound(dwUseSize)) != idx.end()
                                || (it2 = idx2.lower_bound(dwChunkSize)) != idx2.end()))
#else
                        if (size)
#endif
                        {//�ҵ����ʵĿ����ڴ��
                        // Unfit Match;
                                assert((it = idx.lower_bound(dwUseSize)) != idx.end()
                                        || (it2 = idx2.lower_bound(dwChunkSize)) != idx2.end());
                                continue;
                        }
                        else
                              {//û�ҵ����ʵĿ����ڴ��,����һ��
                              //Not Found, Allocate a new Memory Block
                              DWORD dwCurrentChunkSize = m_dwIncrease;
                              if (dwChunkSize > m_dwIncrease )
                                      dwCurrentChunkSize = dwChunkSize;

                              MemoryTrunk     freeTrunk = Preallocate(dwCurrentChunkSize,dwUseSize);

                              nth_index<MemoryTable,0>::type &idxFree=get<0>(FreeTable);
                              nth_index_iterator<MemoryTable,0>::type it0;
                              it0 = idxFree.find(freeTrunk.m_lpVoid);
                              assert(it0 != idxFree.end());
                              idxFree.erase(it0);

                              if (dwCurrentChunkSize != dwChunkSize)
                                        {
                                      MemoryTrunk allocateTrunk = freeTrunk.CutMemory(dwChunkSize,dwUseSize);

                                      AllocateTable.insert(allocateTrunk);
                                      assert(freeTrunk.m_dwChunkSize != 0);
                                      //if (freeTrunk.dwChunkSize != 0)
                                              FreeTable.insert(freeTrunk);
                                      return allocateTrunk.m_lpVoid;
                                          }
                              else
                                      return  freeTrunk.m_lpVoid;
                                  }
                                                }
                                        }while(true);

                                        return NULL;
                                }

MemoryTrunk  MemoryPool::Preallocate(DWORD dwChunkSize,DWORD dwUseSize )
{

        if (dwChunkSize==0)
                return MemoryTrunk(NULL,0,0,NULL,0,0);
//Profile(PerformanceTest);
        boost::recursive_mutex::scoped_lock lock(m_Mutex);
       // Lock Lock (this);
       MemoryTrunk     memoryTrunk(m_pAllocator,
                                                                 dwChunkSize,dwUseSize,
                                                                 m_pAllocator->preallocate(dwChunkSize)
                                                                 //,dwChunkSize
                                                            );

        assert(memoryTrunk.m_lpVoid);
        FreeTable.insert(memoryTrunk);
      //  TRACE("\n Preallocate %u K Free Memory %u K Allocate Memory %u K In Pool\n",
         //       dwChunkSize>>10,GetFreeMemSize()>>10,GetAllocMemSize()>>10 );



        return memoryTrunk;//.lpVoid;
}


bool MemoryPool::FreeInner(LPVOID lpVoid )
{
        if (lpVoid == NULL )
                return false;

//Profile(PerformanceTest);

        boost::recursive_mutex::scoped_lock lock(m_Mutex);
        //Lock Lock ( this );
        //bool  retcodeBack  = MergeBack(lpVoid);
        //bool  retcodeFront = MergeFront(lpVoid);

        //return (retcodeBack || retcodeFront);
        return (MergeBack(lpVoid) | MergeFront(lpVoid));

#if 0
        nth_index<MemoryTable,0>::type &idx=get<0>(AllocateTable);
        nth_index_iterator<MemoryTable,0>::type it = idx.find(lpVoid);
        if (it != idx.end())
        {
                MemoryTrunk     memoryTrunk = *it;
                if (UseSize)
                {
                        //printf("Memory Leak %d \n",std::abs(int(UseSize-memoryTrunk.dwUseSize)));
                        //assert(UseSize == memoryTrunk.dwUseSize);
                }
                idx.erase(it);
                //idx.erase(lpVoid);
                memoryTrunk.CheckStatus();
                FreeTable.insert(memoryTrunk);
        }
        return;
#endif

}

void MemoryPool::FreeRun(DWORD dwTriger )
{
        //ThreadGuard threadGuard(hWnd);

       if (freeCache.size() >= dwTriger)
        {

 //Profile(PerformanceTest);
          boost::recursive_mutex::scoped_lock lock(m_Mutex);
 //Lock Lock (this);

                std::for_each(freeCache.begin(),freeCache.end(),boost::bind(&MemoryPool::FreeInner,this,_1/*,0*/));
                freeCache.clear();
        }


}

void MemoryPool::Free(LPVOID lpVoid,DWORD UseSize)
{
//Profile(PerformanceTest);
   LPVOID    lpHitVoid;
   if (lpVoid == NULL  || !(lpHitVoid = HitTest(lpVoid,false)) )
    {
      //TRACE("Error Free unavailable Memory [0x%lx]\n",lpVoid);

      return;
    }
   else if(lpVoid != lpHitVoid)
   {



     //TRACE("Error Free unavailable Memory offset [0x%lx] Hit [0x%lx]\n",lpVoid,lpHitVoid);
      lpVoid = lpHitVoid;
   }
      //Lock Lock (this);
   boost::recursive_mutex::scoped_lock lock(m_Mutex);
#if 0
                nth_index<MemoryTable,0>::type &idxAlloc=get<0>(AllocateTable);
                nth_index_iterator<MemoryTable,0>::type it = idxAlloc.find(lpVoid);
#else
                nth_index<MemoryTable,8>::type &idxAlloc=get<8>(AllocateTable);
                nth_index_iterator<MemoryTable,8>::type it = idxAlloc.find(lpVoid);
#endif
                if (it != idxAlloc.end())
                {
                        MemoryTrunk     memoryTrunk = *it;
                        if (UseSize)
                        {
                                //printf("Memory Leak %d \n",std::abs(int(UseSize-memoryTrunk.dwUseSize)));
                                assert(UseSize == memoryTrunk.m_dwUseSize);
                        }


                        idxAlloc.erase(it);
                        //idxAlloc.erase(lpVoid);
                        bool bCheckResult = memoryTrunk.CheckStatus();
                        assert(bCheckResult);
                        FreeTable.insert(memoryTrunk);


                        freeCache.insert(lpVoid);
                        //GetThreadPool< typename smart_pool<LOKI_THREAD_POOL_TYPE> >()->resize(LOKI_THREAD_POOL_NUM);
#if 1
if (freeCache.size() > MaxTrimSize)
//AcquireThreadHandleSet.size() )
  //GetThreadPool< typename smart_pool<LOKI_THREAD_POOL_TYPE> >()
  ThreadPoolSingleton<>::GetInstance().schedule(boost::threadpool::prio_task_func(500,boost::bind(&MemoryPool::FreeRun,this, freeCache.size() )));
#else
if (freeCache.size() > AcquireThreadHandleSet.size() )
              //GetThreadPool< typename smart_pool<LOKI_THREAD_POOL_TYPE> >()
              ThreadPool->schedule(boost::bind(FreeRun,this, freeCache.size() ));
#endif
      }

      return;

}



        /********************************************************************************************/
        /*                                      QueryMemoryStatus : Query Memory Status                                                                 */
        /*                                      return Code  =  0 : In Free Memory Table                                                                */
        /*                                                                      1 : In Allocate Memory Table                                                    */
        /*                                                                 -1 : Not In This Memory Pool                                                         */
        /********************************************************************************************/

int MemoryPool::QueryMemoryStatus(LPVOID lpVoid,MemoryTrunk &memoryTrunk)
        {
                if (lpVoid == NULL )
                    return -1;

      //Profile(PerformanceTest);


      //Lock Lock ( ThreadModel );

#if 0
                nth_index<MemoryTable,0>::type &idx=get<0>(AllocateTable);
                nth_index_iterator<MemoryTable,0>::type it = idx.find(lpVoid);
#else
          nth_index<MemoryTable,8>::type &idx=get<8>(AllocateTable);
          nth_index_iterator<MemoryTable,8>::type it = idx.find(lpVoid);
#endif
                if (it != idx.end())
                {
                        memoryTrunk = *it;
                        return  1;
                }
#if 0
                idx = get<0>(FreeTable);
#else
                nth_index<MemoryTable,8>::type &idx2 = get<8>(FreeTable);
#endif
                it = idx2.find(lpVoid);
                if (it != idx2.end())
                {
                        memoryTrunk = *it;
                        return  0;
                }
                else
                        return -1;
        }


bool MemoryPool::MergeBack(LPVOID lpVoid)
        {

  boost::recursive_mutex::scoped_lock lock(m_Mutex);

#if 0
                nth_index<MemoryTable,0>::type &idxFree=get<0>(FreeTable);
                nth_index_iterator<MemoryTable,0>::type it,itBack;
#else
                nth_index<MemoryTable,8>::type &idxFree=get<8>(FreeTable);
                nth_index_iterator<MemoryTable,8>::type it,itBack;

#endif
                //nth_index<MemoryTable,7>::type &idxFree7 = get<7>(FreeTable);
                //nth_index_iterator<MemoryTable,7>::type itNext;


                LPVOID  lpNextVoid;

                bool    bRetcode = false;

#if 0
                while( ( it = idxFree.find(lpVoid))!= idxFree.end()
                         && (++(itBack = it))!=idxFree.end() )
#else
                //�ҳ���β���ڵĿ�
                while( (it = idxFree.find(lpVoid))!= idxFree.end()
                        && (itBack = idxFree.find( (lpNextVoid = (/*FreeTable.project<7>*/(it)->GetChunkTail())))) != idxFree.end() )
#endif
                {
                        assert(lpVoid == it->m_lpVoid && itBack->m_lpVoid > lpVoid && itBack != it );
                        //assert(lpVoid == it->lpVoid && lpNextVoid > lpVoid );

                        MemoryTrunk currentTrunk = *it;
                        MemoryTrunk backTrunk = *itBack;
                        //�ж��Ƿ���β����
                        if ( currentTrunk.m_RawChunkID ==  backTrunk.m_RawChunkID &&
                                currentTrunk.GetChunkTail() == backTrunk.m_lpVoid
                                //((char *)currentTrunk.lpVoid)+currentTrunk.dwChunkSize == ((char *)backTrunk.lpVoid)
                                )
                        {


                        //�ڴ�����,���кϲ�
                                //idxFree.erase(it);
                                //ɾ�����ϲ���(���ڵ���ָ�������Ч,��Ҫ���»�ȡ)
                                //it1 = idx.find(backTrunk.lpVoid);
                                //idxFree.erase(it1);
                                //idxFree.erase(currentTrunk.lpVoid);
  #if 0
                                idxFree.erase(it);
                                idxFree.erase(backTrunk.m_lpVoid);
  #else
  #if 0
                                it = idxFree.erase(it,++itBack);
  #else
                                idxFree.erase(it);
                                idxFree.erase(itBack);
  #endif
                                //assert(it->lpVoid > currentTrunk.lpVoid);
                                assert(idxFree.find(backTrunk.m_lpVoid)==idxFree.end() );
                                //assert(it == itBack);
  #endif
                                //�ϲ�

                                if(currentTrunk.m_pAllocator != backTrunk.m_pAllocator)
                                        continue;

                                MemoryTrunk     allocateTrunk(
                                        currentTrunk.m_pAllocator,
                                        currentTrunk.m_dwChunkSize + backTrunk.m_dwChunkSize,
                                        currentTrunk.m_dwChunkSize + backTrunk.m_dwUseSize,
                                        currentTrunk.m_lpVoid,
                                        currentTrunk.m_dwRawChunkSize,
                                        currentTrunk.m_RawChunkID
                                        );



                                //FreeTable.insert(currentTrunk);
                                //�ݹ����
                                //return MergeBack(currentTrunk.lpVoid);
                                FreeTable.insert(allocateTrunk);
                                //�ݹ����
                                bRetcode = true;

                        }
                        else
                                break;


                }

                //if    (bRetcode)
                //      TRACE("Found Back Node To Merge\n");

                return          bRetcode;
                //return        FreeTable.size();
        }

bool MemoryPool::MergeFront(LPVOID &lpVoid)
{

//Profile(PerformanceTest);
  boost::recursive_mutex::scoped_lock lock(m_Mutex);
#if 0
                nth_index<MemoryTable,0>::type &idxFree=get<0>(FreeTable);
                //nth_index_iterator<MemoryTable,0>::type it,it1;// = idx.find(lpVoid);
                nth_index_iterator<MemoryTable,0>::type it;// = idx.find(lpVoid);
                //nth_index<MemoryTable,0>::type::reverse_iterator itFront;

                nth_index<MemoryTable,7>::type &idxFree7 = get<7>(FreeTable);
                nth_index_iterator<MemoryTable,7>::type itPrev;
#else
                nth_index<MemoryTable,8>::type &idxFree=get<8>(FreeTable);
                nth_index_iterator<MemoryTable,8>::type it;// = idx.find(lpVoid);

                nth_index<MemoryTable,9>::type &idxFree7 = get<9>(FreeTable);
                nth_index_iterator<MemoryTable,9>::type itPrev;

#endif


                bool    bRetcode = false;
#if 0
                while( ( /*itFront =*/ it = idxFree.find(lpVoid))!= idxFree.end() /*&& it != idxFree.begin()*/)
#else
                //�ж��Ƿ���λ����
                while(
                                ( it = idxFree.find(lpVoid))!= idxFree.end() &&
                                (itPrev = idxFree7.find(lpVoid)) != idxFree7.end()
                         )
#endif
                {

                        assert( itPrev->m_lpVoid < lpVoid );

                        nth_index_iterator<MemoryTable,8>::type itFront = FreeTable.project<8>(itPrev);
                        assert(
                                        //FreeTable.project<7>(itFront)->GetChunkTail() == lpVoid //&&
                                        itPrev->GetChunkTail() == lpVoid &&
                                        itFront->GetChunkTail() == lpVoid
                                    //itFront != idxFree.end()
                                  );

                        assert(lpVoid == it->m_lpVoid && itFront->m_lpVoid < lpVoid  );


                        MemoryTrunk currentTrunk = *it;
                        MemoryTrunk frontTrunk = *itFront;
                        assert
                                (
                                frontTrunk.m_RawChunkID == currentTrunk.m_RawChunkID &&
                                frontTrunk.GetChunkTail() == currentTrunk.m_lpVoid
                                );

                        if (
                                frontTrunk.m_RawChunkID == currentTrunk.m_RawChunkID &&
                                frontTrunk.GetChunkTail() == currentTrunk.m_lpVoid
                                //((char *)frontTrunk.lpVoid)+frontTrunk.dwChunkSize == ((char *)currentTrunk.lpVoid)
                                //frontTrunk.dwRawChunkSize == currentTrunk.dwRawChunkSize
                                )
                        {//�ڴ�����,���кϲ�
                          //ɾ��currentTrunk;


#if 0
                                idxFree.erase(currentTrunk.m_lpVoid);
                                idxFree.erase(frontTrunk.m_lpVoid);
#else
#if 0
                                it = idxFree.erase(itFront,++it);
#else
                                idxFree.erase(itFront);
                                idxFree.erase(it);

#endif
                                //assert(it->lpVoid > currentTrunk.lpVoid);
                                assert(idxFree.find(currentTrunk.m_lpVoid)==idxFree.end());
#endif

                                //�ϲ�
                                if(currentTrunk.m_pAllocator != frontTrunk.m_pAllocator)
                                        continue;

#if 1
                                MemoryTrunk     allocateTrunk(
                                        currentTrunk.m_pAllocator,
                                        frontTrunk.m_dwChunkSize + currentTrunk.m_dwChunkSize,
                                        frontTrunk.m_dwChunkSize+currentTrunk.m_dwUseSize,
                                        frontTrunk.m_lpVoid,frontTrunk.m_dwRawChunkSize,
                                        frontTrunk.m_RawChunkID
                                        );
#else
                                MemoryTrunk     allocateTrunk = frontTrunk;
                                allocateTrunk.Init(
                                        frontTrunk.m_dwChunkSize + currentTrunk.m_dwChunkSize,
                                        frontTrunk.m_dwChunkSize+currentTrunk.m_dwUseSize,
                                        frontTrunk.m_lpVoid
                                        );

#endif

                                FreeTable.insert(allocateTrunk);
                                lpVoid = allocateTrunk.m_lpVoid;
                                bRetcode = true;
                        }
                        else
                                break;

                }

                //if(bRetcode)
                //      TRACE("Found Front Node To Merge\n");


                return  bRetcode;
        }

size_t MemoryPool::Trim(DWORD dwRequiredSize,DWORD nHit,DWORD nCount )
        {
                //�ϲ������ڴ��
      //Profile(PerformanceTest);


     // Lock Lock (this);
  boost::recursive_mutex::scoped_lock lock(m_Mutex);
      size_t  nTrimTrunk = 0;
      size_t  nClearExpired = 0;
      size_t  nHitCount = 0;

#if 1
      nth_index<MemoryTable,0>::type &idxFree=get<0>(FreeTable);
#else
      nth_index<MemoryTable,8>::type &idxFree=get<8>(FreeTable);
#endif
      nth_index<MemoryTable,2>::type &idxFree2=get<2>(FreeTable);

      for( nth_index_iterator<MemoryTable,0>::type it = idxFree.begin();it!= idxFree.end();)
      {
              //MemoryTrunk   memoryTrunk;
              MemoryTrunk memoryTrunk = *it;



              //bool  bMergeBack,bMergeFront;
              bool bMergeBack = MergeBack(memoryTrunk.m_lpVoid);
              LPVOID  lpVoid = memoryTrunk.m_lpVoid;


              bool bMergeFront = MergeFront(/*memoryTrunk.*/lpVoid);
              if ( !bMergeBack && !bMergeFront)
              {

                //It's full Memory Chunk. To Check Next.
                      it++;
                      continue;
              }

              if(bMergeBack)
              {
                      nTrimTrunk ++;
                      freeCache.erase(memoryTrunk.m_lpVoid);
              }
              if(bMergeFront)
              {

                      assert(lpVoid <= memoryTrunk.m_lpVoid);
                      nTrimTrunk ++;
                      freeCache.erase(lpVoid);
              }

#if 1
              DWORD   dwCount = (DWORD)idxFree2.count(dwRequiredSize);
              if (dwCount)
              {//find Match size Trunk;

                      nHitCount = dwCount;
              }
#else
              DWORD   dwCount = (DWORD)std::distance(
                                                                                              idxFree2.lower_bound(dwRequiredSize),
                                                                                              idxFree2.end()
                                                                                              );
              if (dwCount)
              {//find Match size Trunk;
                      nHitCount = dwCount;
              }
#endif


              //if ( nHitCount <= nHit  && nTrimTrunk <= nCount)
              if (nHitCount <= nHit && nTrimTrunk <= nCount)
              {

                      //Continue with No Match Size and Un Reach The Max Limit
              }
              else
              {
                      //TRACE("\r\r\r\r\r\rr\r\r\r\r\r\r\r\rTrim Hit Finish\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r");
                      break;
              }

              it = idxFree.upper_bound(/*memoryTrunk.*/lpVoid);
              if (it!= idxFree.end())
              {
               assert(it->m_lpVoid > memoryTrunk.m_lpVoid && it->m_lpVoid  > lpVoid);

                      //if(it->dwChunkSize == )

              }

      }
#if 1

      if (freeCache.size())
	  {
        //(*LogMessage)<< log4cpp::Priority::INFO
        //                               <<"  ThreadPoolSingleton";
         //GetThreadPool< typename smart_pool<LOKI_THREAD_POOL_TYPE> >()
        ThreadPoolSingleton<>::GetInstance().schedule(boost::threadpool::prio_task_func(500,boost::bind(&MemoryPool//<ThreadingModel>
	                                                                                             ::FreeRun,this, 1 )));
	  }
#else
      if (freeCache.size())
        ThreadPoolSingleton<>::GetInstance().schedule(boost::bind(FreeRun,this, 1 ));

#endif

#if 1
                nth_index<MemoryTable,6>::type &idxFree6 =get<6>(FreeTable);

                if (idxFree6.count(true) && m_dwExpiredSecond)
                {

                        //GetThreadPool< typename smart_pool<LOKI_THREAD_POOL_TYPE> >()
                  ThreadPoolSingleton<>::GetInstance().schedule(boost::threadpool::prio_task_func (100,boost::bind(&MemoryPool//<ThreadingModel>
                                                                                                        ::ClearExpire,this,m_dwExpiredSecond)));

                  //TRACE("Invoke ClearExpire\n");
                }
#endif

                //return                nTrimTrunk;
                return                  min(nHitCount,nTrimTrunk);

        }

template<DWORD Nth>
bool MemoryPool::RunNtimes(typename boost::function0<void> func)
{
        static  DWORD dwNth = Nth;
        if (dwNth)
        {
                func();
                dwNth--;
                return  true;
        }
        else
                return false;

}


LPVOID MemoryPool::HitTest(LPVOID lpVoid,bool bFree )
{

//Profile(PerformanceTest);


      if (bFree)
      {
        boost::recursive_mutex::scoped_lock lock(m_Mutex);
           //   Lock Lock (this);
#if 1

#if 0
                        nth_index<MemoryTable,0>::type &idxFree=get<0>(FreeTable);
                        nth_index_iterator<MemoryTable,0>::type it;

                        nth_index<MemoryTable,7>::type &idxFree7=get<7>(FreeTable);
                        nth_index_iterator<MemoryTable,7>::type it7 ;
#else
                        nth_index<MemoryTable,8>::type &idxFree=get<8>(FreeTable);
                        nth_index_iterator<MemoryTable,8>::type it;

                        nth_index<MemoryTable,7>::type &idxFree7=get<7>(FreeTable);
                        nth_index_iterator<MemoryTable,7>::type it7 ;
#endif




#if 0
                        it = idxFree.lower_bound(lpVoid);
                        it7 = idxFree7.upper_bound(lpVoid);
#else
                        it = idxFree.find(lpVoid);
                        it7 = idxFree7.upper_bound(lpVoid);
#endif


        #if 1
                        bool    bIt = false;
                        bool    bIt7 = false;

                        if(
                                it              != idxFree.end()        &&      (bIt    =       (it->m_lpVoid <= lpVoid))
                                ||
                                it7             != idxFree7.end()       &&      (bIt7   =       (it7->m_lpVoid <= lpVoid))
                                )
                        {

                                if(bIt)
                                        return  it->m_lpVoid;
                                if(bIt7)
                                        return  it7->m_lpVoid;
                        }
                        else
                                return NULL;
        #endif

#endif
                }
                else
                {
                      //  Lock Lock (this);
                  boost::recursive_mutex::scoped_lock lock(m_Mutex);
#if 1
#if 0
                        nth_index<MemoryTable,0>::type &idxAlloc=get<0>(AllocateTable);
                        nth_index_iterator<MemoryTable,0>::type it;

                        nth_index<MemoryTable,7>::type &idxAlloc7=get<7>(AllocateTable);
                        nth_index_iterator<MemoryTable,7>::type it7 ;

#else
                        nth_index<MemoryTable,8>::type &idxAlloc=get<8>(AllocateTable);
                        nth_index_iterator<MemoryTable,8>::type it;

                        nth_index<MemoryTable,7>::type &idxAlloc7=get<7>(AllocateTable);
                        nth_index_iterator<MemoryTable,7>::type it7 ;

#endif

#if 0
                        it = idxAlloc.lower_bound(lpVoid);
                        it7 = idxAlloc7.upper_bound(lpVoid);

#else
                        it = idxAlloc.find(lpVoid);
                        it7 = idxAlloc7.upper_bound(lpVoid);

#endif


        #if 1
                        bool    bIt = false;
                        bool    bIt7 = false;

                        if(
                                it              != idxAlloc.end()       &&      (bIt    =       (it->m_lpVoid <= lpVoid))
                                ||
                                it7             != idxAlloc7.end()      &&      (bIt7   =       (it7->m_lpVoid <= lpVoid))
                                )
                        {

                                if(bIt)
                                        return  it->m_lpVoid;
                                if(bIt7)
                                        return  it7->m_lpVoid;
                        }
                        else
                                return NULL;
        #endif

#else
                        nth_index<MemoryTable,0>::type &idxAlloc=get<0>(AllocateTable);
                        nth_index_iterator<MemoryTable,0>::type it ;//= idxAlloc.find(lpVoid);
                        //if (it != idxAlloc.end())
                        //{
                        //      return lpVoid;
                        //}
                        //else
                        {
                                it = idxAlloc.lower_bound(lpVoid);
                                if (it != idxAlloc.end())// &&*/ it != idxAlloc.begin())
                                {

                                        MemoryTrunk memoryTrunk = *it;
                                        assert(((char *)memoryTrunk.m_lpVoid)+ memoryTrunk.m_dwChunkSize > (char *)lpVoid );
                                        if (((char *)memoryTrunk.m_lpVoid)+ memoryTrunk.m_dwChunkSize > (char *)lpVoid )
                                        {
                                                if (memoryTrunk.m_lpVoid <=  lpVoid )
                                                        return memoryTrunk.m_lpVoid;
                                                else
                                                {
                                                        assert(it->m_lpVoid > lpVoid);
                                                        nth_index<MemoryTable,0>::type::reverse_iterator itFront(it);
                                                        if (itFront== idxAlloc.rend())
                                                                return NULL;
                                                        //it--;
                                                        MemoryTrunk memoryTrunkFront = *itFront;
                                                        if (((char *)memoryTrunkFront.m_lpVoid)+ memoryTrunkFront.m_dwChunkSize > (char *)lpVoid )
                                                        {
                                                                if (memoryTrunkFront.m_lpVoid <=  lpVoid )
                                                                        return memoryTrunkFront.m_lpVoid;
                                                                else
                                                                {//May Be It's not Impossible happen
                                                                        assert(false);
                                                                        return NULL;
                                                                }

                                                        }
                                                        else if (((char *)memoryTrunkFront.m_lpVoid)+ memoryTrunkFront.m_dwChunkSize == (char *)lpVoid )
                                                        {
                                                                TRACE("This Memory [0x%lx] Had Free\n",(long)lpVoid);
                                                                return NULL;
                                                                //assert(false);
                                                        }
                                                        else//Not Neighbour
                                                                return  NULL;

                                                }
                                        }
                                }
                                else if (!idxAlloc.empty())
                                {//Maybe In the Last Trunk
                                        it--;
                                        MemoryTrunk memoryTrunk = *it;
                                        //assert(((char *)memoryTrunk.lpVoid)+ memoryTrunk.dwChunkSize > (char *)lpVoid );
                                        if (((char *)memoryTrunk.m_lpVoid)+ memoryTrunk.m_dwChunkSize > (char *)lpVoid )
                                        {
                                                if (memoryTrunk.m_lpVoid <=  lpVoid )
                                                        return memoryTrunk.m_lpVoid;
                                                else
                                                        return NULL;
                                        }
                                        else//Not Neighbour
                                                return  NULL;

                                }
                                else
                                        return NULL;

                        }
#endif

                }

        }

size_t MemoryPool::ClearExpire(DWORD &dwExpiredSec)
{
        //ThreadGuard(hWnd);

//Profile(PerformanceTest);




        if (dwExpiredSec < 2)
        {
                dwExpiredSec = 120;
                return 0;
        }

        size_t  nCount = 0;
        size_t  itCount = 0;

        DWORD   dwExpiredTick = dwExpiredSec * 1000;
        //DWORD dwTick          =       GetTickCount();

        {

              //  Lock Lock (this);
          boost::recursive_mutex::scoped_lock lock(m_Mutex);


                //if (Trim())
                {



#if 1
            nth_index<MemoryTable,6>::type &idxFree6 =get<6>(FreeTable);

                        typedef std::pair<
                               nth_index_iterator<MemoryTable,6>::type,
                                nth_index_iterator<MemoryTable,6>::type
                        > Iterator_6_Pair;
                        Iterator_6_Pair it6Pair = idxFree6.equal_range(true);
                        nth_index_iterator<MemoryTable,6>::type begin = it6Pair.first;
                        nth_index_iterator<MemoryTable,6>::type end = it6Pair.second;
                        nth_index_iterator<MemoryTable,6>::type it = begin;
                        for(  ;it!= end;it++)
                        {
                                assert(it->m_dwRawChunkSize == it->m_dwChunkSize);

								boost::posix_time::ptime current(boost::posix_time::microsec_clock::local_time());
								boost::posix_time::time_duration duration = 	current - (it->m_TimeCreateTime);
								int elapseSecond = duration.total_seconds();





                                if(
                                       // it->m_dwTimeCreateTime < (GetTickCount() - dwExpiredTick) &&
										elapseSecond  > dwExpiredSec 
                                        && FreeTable.size() > 1
                                        )
                                {
                                        MemoryTrunk freeTrunk = *it;
                                        //The Memory Trunk is expired
                                        //freeTrunk.m_pAllocator->deallocate(freeTrunk.lpVoid,freeTrunk.dwChunkSize);
                                        freeTrunk.Deallocate();
                                       // (*LogMessage)<< log4cpp::Priority::ERROR
                                        //  <<__FUNCTION__<<" Had Release Expired Trunk size "<<freeTrunk.m_dwChunkSize;
                                       // TRACE("\nHad Release Expired Trunk size [%d] Memory",freeTrunk.m_dwChunkSize/*__FUNCTION__,*//*itCount+1*/);
                                        itCount++;
                                }
                        }
                        idxFree6.erase(begin,end);
#else





                        <MemoryTable,0>::type &idxFree=get<0>(FreeTable);
                        for( nth_index_iterator<MemoryTable,0>::type it = idxFree.begin();it!= idxFree.end();)
                        {
                                if(it->m_dwRawChunkSize == it->m_dwChunkSize
                                        && it->m_dwTimeCreateTime < (GetTickCount() - dwExpiredTick)
                                        && FreeTable.size() > 1)
                                {
                                        MemoryTrunk freeTrunk = *it;
                                        //The Memory Trunk is expired
                                        /*AllocFactory::Instance(AllocateID).*/
                                        //freeTrunk.m_pAllocator->deallocate(freeTrunk.lpVoid,freeTrunk.dwChunkSize);
                                        freeTrunk.Deallocate();
                                        TRACE("\nHad Release Expired Trunk size [%d] Memory",freeTrunk.m_dwChunkSize/*__FUNCTION__,*//*itCount+1*/);
                                        itCount++;
                                        idxFree.erase(it);
                                        it = idxFree.upper_bound(freeTrunk.m_lpVoid);
                                }
                                else
                                        it++;
                        }
#endif

                }


        }

        if (itCount)
        {//Clear Trunk
                dwExpiredSec += (DWORD)itCount;
               // (*LogMessage)<< log4cpp::Priority::INFO
                //               <<__FUNCTION__<<" Had Release Total Expired Trunk "<<itCount;
             //   TRACE("\n %s Had Release Total Expired Trunk [%d] Memory\n",__FUNCTION__,itCount);
        }
        else
        {//No Expired Trunk
                if (dwExpiredSec)
                        dwExpiredSec --;
        }
        //Sleep(dwExpiredTick);
        return itCount;
}




void MemoryPool::GetParam(size_t &ChunkSize_, size_t &Increase_,size_t &Gap_)
{
    ChunkSize_ = m_dwChunkSize,
    Increase_  = m_dwIncrease;
    Gap_       = m_dwGap;
}

void MemoryPool::SetParam(size_t ChunkSize_,size_t Increase_,size_t Gap_)
{
    m_dwChunkSize =(ChunkSize_ && ChunkSize_ == m_dwChunkSize   ? m_dwChunkSize : ChunkSize_);
    m_dwIncrease = (Increase_ && Increase_ == m_dwIncrease  ? m_dwIncrease : Increase_);
    m_dwGap    = (Gap_ == m_dwGap ? m_dwGap : Gap_);
}

void MemoryPool::InitOnce( )
{
        MemoryTrunk     memoryTrunk = Preallocate(m_dwChunkSize);
        //assert(memoryTrunk.lpVoid);
        //FreeTable.insert(memoryTrunk);
}

DWORD   MemoryPool::GetAllocMemSize( )
{
#if 0
      nth_index<MemoryTable,0>::type &idxFree=get<0>(AllocateTable);
      DWORD dwTotalFree = 0;
      std::for_each(
              idxFree.begin(),
              idxFree.end(),
              InvadeTotal<MemoryTrunk,DWORD>(dwTotalFree,&MemoryTrunk::m_dwChunkSize)
              );
      return  dwTotalFree;
#else
      return  GetMemSize(false);
#endif
}

DWORD   MemoryPool::GetFreeMemSize( )
{
#if 0
        nth_index<MemoryTable,0>::type &idxFree=get<0>(FreeTable);
        DWORD dwTotalFree = 0;
        std::for_each(
                                        idxFree.begin(),
                                        idxFree.end(),
                                        InvadeTotal<MemoryTrunk,DWORD>(dwTotalFree,&MemoryTrunk::m_dwChunkSize)
                                 );
        return  dwTotalFree;
#else
        return  GetMemSize();
#endif
}

DWORD   MemoryPool::GetMemSize(bool bFree)
{
      //nth_index<MemoryTable,0>::type &idxAlloc      =       get<0>(AllocateTable);
      //nth_index<MemoryTable,0>::type &idxFree               =       get<0>(FreeTable);

      //if (bFree)
      nth_index<MemoryTable,0>::type &idx = (bFree ? get<0>(FreeTable) : get<0>(AllocateTable));

      size_t dwTotalFree = 0;
#if 0
      std::for_each(
              idx.begin(),
              idx.end(),
              InvadeTotal<MemoryTrunk,DWORD>(dwTotalFree,&MemoryTrunk::m_dwChunkSize)
              );
#else
      dwTotalFree = accumulate(idx.begin(),idx.end(),(size_t)0,InvadeTotal<MemoryTrunk,size_t>(dwTotalFree,&MemoryTrunk::m_dwChunkSize));

#endif
      return  dwTotalFree;
}




