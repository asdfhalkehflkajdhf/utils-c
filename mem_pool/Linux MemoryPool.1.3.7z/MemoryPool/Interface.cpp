/*
 * Interface.cpp
 *
 *  Created on: 2009-7-14
 *      Author: yul
 */

#include "Interface.h"
#include "MemoryPool.h"
#include "./globalDefine/Constant.h"
#include "./util/SingletonHolder.h"

LPVOID Malloc(DWORD dwSize,DWORD dwGap_ )
{
  SingletonHolder<MemoryPool>::GetInstance().Malloc(dwSize, dwGap_);
}

void Free(LPVOID lpVoid,DWORD UseSize)
{
  SingletonHolder<MemoryPool>::GetInstance().Free(lpVoid, UseSize);
}
