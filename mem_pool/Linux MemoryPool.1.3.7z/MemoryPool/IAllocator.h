#pragma once
#ifndef	__IALLOCATOR_H__
#define	__IALLOCATOR_H__

//#include "./util/Constant.h"

#define		TypeCPPAllocator  0
#define		TypeCAllocator  1
#define		TypeVirtualMemoryAllocator  2
#define		TypeHeapAllocator  3
#define		TypeShareMemAllocator  4
//namespace Loki
//{
#include <iostream>
#include <string>


	class IAllocator
	{
	public:
		//typedef std::size_t    size_type;
		//typedef std::ptrdiff_t difference_type;

		virtual void	*preallocate(std::size_t size) = 0;
		virtual void	*allocate(void *lpBase,std::size_t size) = 0;
		virtual void	deallocate(void *lpPtr,std::size_t size  = 0) = 0;
		virtual void	setguard(void *lpguard,std::size_t size) = 0;
		virtual void	init(void *lpvoid,std::size_t size) = 0;
		virtual bool	CheckStatus(void *lpvoid,std::size_t size) = 0;
		virtual char*	malloc(const std::size_t bytes) = 0;
		virtual void	free(char * const block) = 0;

	};

	class AllocFactory
	{
	public:
		static IAllocator & Instance(int typeID);

	};


//}
#endif

