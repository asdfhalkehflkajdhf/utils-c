#pragma once

#ifndef	__ALLOCATE_H__
#define	__ALLOCATE_H__

//#include "stdafx.h"

#include <map>
#include <boost/config.hpp> /* keep it first to prevent nasty warns in MSVC */
#include <boost/smart_ptr.hpp>

#include "IAllocator.h"


#include "./globalDefine/Constant.h"

//#ifndef	__Configure_H__
//#include "Configure.h"
//#endif

//#ifndef __GlobalDef_H___
//	#include "GlobalDef.h"
//#endif
//
//
//#ifndef	__STL_Configure_H__
//#include "STL_Configure.h"
//#endif
//
//#ifndef	__System_Configure_H__
//#include "System_Configure.h"
//#endif
//
//
//


//#ifndef	__TCHAR_H__
//	#include <tchar.h>
//	#define __TCHAR_H__
//#endif


#pragma message(__FILE__)



//namespace Loki
//{

	//This File has defined some Simple and Plain Allocator to use system Memory API
	//Plain CPP Allocator


//#define DefaultAllocator	VirtualMemoryAllocator
	//CAllocator 




	class CPPAllocator
		: public IAllocator
	{
	public:
		//CPPAllocator();
		void	*preallocate(size_t size);
		void	*allocate(void *lpBase,size_t size);
		void	deallocate(void *lpPtr,size_t size  = 0);
		void	setguard(void *lpguard,size_t size);
		void	init(void *lpvoid,size_t size);
		bool	CheckStatus(void *lpvoid,size_t size);
		char *	malloc(const size_t bytes);
		void	free(char * const block);

		typedef std::size_t    size_type;
		typedef std::ptrdiff_t difference_type;
	private:
		std::map<LPVOID,size_type>	MemCache;


	};

	//Plain C Allocator
	class CAllocator
		: public IAllocator
	{
	public:
		//CAllocator();
		void	*preallocate(size_t size);
		void	*allocate(void *lpBase,size_t size);
		void	deallocate(void *lpPtr,size_t size = 0);
		void	setguard(void *lpguard,size_t size);
		void	init(void *lpvoid,size_t size);
		bool	CheckStatus(void *lpvoid,size_t size);
		char *	malloc(const size_t bytes);
		void	free(char * const block);

		typedef std::size_t    size_type;
		typedef std::ptrdiff_t difference_type;

	private:
		std::map<LPVOID,size_type>	MemCache;


	};




//}//namespace Loki



#endif//__ALLOCATE_H__
