#ifndef REGEXTEST_H
#define REGEXTEST_H

int regextestMatch(const char *string);

#endif
