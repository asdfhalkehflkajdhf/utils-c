#ifndef FTPPRIVATE_H
#define FTPPRIVATE_H

struct FtpIpPrivate{
	struct addrinfo *info;
};

#endif
